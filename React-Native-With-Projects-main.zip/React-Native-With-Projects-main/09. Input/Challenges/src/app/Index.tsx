import { View } from "react-native";
import MyForm from "../components/MyForm";

const Index = () => {
  return (
    <View>
      <MyForm />
    </View>
  );
};

export default Index;
