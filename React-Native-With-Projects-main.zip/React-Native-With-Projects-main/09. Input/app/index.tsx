import { TextInput, View } from "react-native";
import InputComponent from "./components/InputComponent";

const Index = () => {
  return (
    <View>
      <InputComponent />
    </View>
  );
};

export default Index;
