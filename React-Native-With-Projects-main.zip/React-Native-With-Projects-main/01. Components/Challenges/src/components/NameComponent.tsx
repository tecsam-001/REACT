import { View, Text } from "react-native";

const NameComponent = () => {
  return (
    <View>
      <Text>My name is HuXn WebDev</Text>
    </View>
  );
};

export default NameComponent;
