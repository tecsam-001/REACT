import { View, Text } from "react-native";

const XHandleComponent = () => {
  return (
    <View>
      <Text>Here is my X handle @huxwebdev</Text>
    </View>
  );
};

export default XHandleComponent;
