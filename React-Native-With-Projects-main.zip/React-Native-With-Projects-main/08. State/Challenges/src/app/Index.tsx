import { View, Text } from "react-native";
import ToggleButton from "../components/ToggleButton";
import WeatherApp from "../components/Weather";
import ColorPicker from "../components/ColorPicker";
import TodoList from "../components/TodoList";

const Index = () => {
  return (
    <View>
      {/* <ToggleButton /> */}
      {/* <WeatherApp /> */}
      {/* <ColorPicker /> */}
      <TodoList />
    </View>
  );
};

export default Index;
