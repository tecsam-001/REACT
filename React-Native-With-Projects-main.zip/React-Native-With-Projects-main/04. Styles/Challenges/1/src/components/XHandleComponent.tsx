import { View, Text } from "react-native";
import st from "../style";

const XHandleComponent = () => {
  return (
    <View style={st.shadowStyle}>
      <Text>Here is my X handle @huxwebdev</Text>
    </View>
  );
};

export default XHandleComponent;
