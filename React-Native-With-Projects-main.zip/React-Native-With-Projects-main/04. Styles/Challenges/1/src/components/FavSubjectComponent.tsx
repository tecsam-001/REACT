import { View, Text } from "react-native";
import st from "../style";

const FavSubjectComponent = () => {
  return (
    <View style={st.shadowStyle}>
      <Text>I love Math</Text>
    </View>
  );
};

export default FavSubjectComponent;
