import { View, Text, StyleSheet } from "react-native";
import st from "../style";

const NameComponent = () => {
  return (
    <View style={st.shadowStyle}>
      <Text>My name is HuXn WebDev</Text>
    </View>
  );
};

export default NameComponent;
