import { View, Text } from "react-native";
import ComponentC from "./ComponentC";

const ComponentB = () => {
  return <ComponentC />;
};

export default ComponentB;
