import { View, Text } from "react-native";
import Home from "@/components/Home";

const Index = () => {
  return <Home />;
};

export default Index;
