import { View } from "react-native";
import HugeList from "../components/HugeList";

const Index = () => {
  return (
    <View>
      <HugeList />
    </View>
  );
};

export default Index;
