import { View } from "react-native";
import CardComponent from "../components/CardComponent";

const Index = () => {
  return (
    <View>
      <CardComponent />
    </View>
  );
};

export default Index;
