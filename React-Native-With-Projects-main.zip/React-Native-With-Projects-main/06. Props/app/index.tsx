import ParentComponent from "./components/ParentComponent";

const Index = () => {
  return <ParentComponent />;
};

export default Index;
