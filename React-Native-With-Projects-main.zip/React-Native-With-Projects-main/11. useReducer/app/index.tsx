import { View, Text } from "react-native";
import Counter from "./components/Counter";

const Index = () => {
  return (
    <View>
      <Counter />
    </View>
  );
};
export default Index;
